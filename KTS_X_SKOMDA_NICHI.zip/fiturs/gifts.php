<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="mcontainer">
        <img src="../logo1.png" alt="apa boleh saya meso?" width="100px" height="100px">
        <div class="navcont">
            <div class="other">
                <a href="comms.php">Commission</a>
                <a href="prems.php">Premium</a>
                <a href="tsp.php">Support</a>
            </div>
        </div>
        <a href="../mlogout.php">i ᓵ⚍ ∷ᓭᒷ ||𝙹⚍  ℸ ̣𝙹 ||𝙹⚍ ∷ 7ℸ ̣⍑  ⊣ᒷリᒷ∷ᔑℸ ̣╎𝙹リ</a>
    </div>
</body>
</html>