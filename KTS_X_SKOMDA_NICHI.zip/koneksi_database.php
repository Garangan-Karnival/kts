<?php
// isi nama host, username mysql, dan password mysql anda
$databaseHost= "localhost";
$databaseName = "helper_game";
$databaseUsername = "root";
$databasePassword = "";
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);